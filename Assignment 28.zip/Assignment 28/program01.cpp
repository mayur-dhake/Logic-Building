//Write a program which accept one number and position from user and check whether bit at that position is
//is ON or OFF. If bit is one return true otherwise return false.

#include<iostream>
using namespace std;

typedef unsigned int UINT;

bool CheckBit(UINT iNo, UINT iPos)
{
    UINT iMask = 0X00000001;
    UINT iResult = 0;

    iMask = iMask << (iPos - 1);

    iResult = iNo & iMask;

    if(iResult == 0X00000000)
    {
        return false;
    }
    else
    {
        return true;
    }
}

int main()
{
    UINT iValue = 0;
    UINT iBit = 0;
    bool bRet = 0;

    cout<<"Enter number :"<<"\n";
    cin>>iValue;

    cout<<"Enter the position :"<<"\n";
    cin>>iBit;

    bRet = CheckBit(iValue, iBit); 

    if(bRet == false)
    {
        cout<<iBit<<"th Bit is OFF"<<"\n";
    }
    else
    {
        cout<<iBit<<"th Bit is ON"<<"\n";
    }


    return 0;
}