//Write a program which accept one number from user and toggle contents of first and last nibble of that number.
//Return Modified number.(Nibble is a group of four bits).

#include<iostream>
using namespace std;

typedef unsigned int UINT;

UINT ToggleBit(UINT iNo)
{
    UINT iMask1 = 0X0000000F;
    UINT iMask2 = 0XF0000000;

    UINT iMask = 0X00000000;

    UINT iResult = 0;

    iMask = iMask1 | iMask2;

    iResult = iNo ^ iMask;

    return iResult;

    
}

int main()
{
    UINT iValue = 0;
    UINT iBit = 0;
    UINT iRet = 0;

    cout<<"Enter the number :"<<"\n";
    cin>>iValue;

    iRet = ToggleBit(iValue);

    cout<<"Modified number after toggling bit is :"<<iRet<<"\n";

    return 0;
}