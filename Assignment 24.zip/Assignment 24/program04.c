//Write a program which accept string from user and accept one character. Return index of last occurance of 
//that character.
#include<stdio.h>
#define ERR_NOTFOUND -1

int LastCharacter(char *str, char ch)
{
    int iCnt = 0;
    int iPos = ERR_NOTFOUND;
    while(*str != '\0')
    {
        if(*str == ch)
        {
            iPos = iCnt;
        }
        str++;
        iCnt++;
    }
    return iPos;
}

int main()
{
    char Arr[20];
    char cValue = '\0';
    int iRet = 0;

    printf("Enter the string :");
    scanf("%[^'\n']s",Arr);

    fflush(stdin);

    printf("Enter the character :");
    scanf("%c",&cValue);

    iRet = LastCharacter(Arr, cValue);
    if(iRet == ERR_NOTFOUND)
    {
        printf("Ther is no such character in the string.");
    }
    else
    {
        printf("Return of Last Occurance of character is %d",iRet);
    }

    return 0;
}