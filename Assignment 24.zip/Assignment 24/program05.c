//Write a program which accept string from user and reverse that string in place.

#include<stdio.h>

void strRevX(char *str)
{
    char *start = NULL;
    char *end = NULL;
    char temp;

    start = str;
    end = str;

    while (*end != '\0')
    {
        end++;
    }
    end--;

    for ( ; start < end; start++,end--)
    {
        temp = *start;
        *start = *end;
        *end = temp;

    }
    

    
}

int main()
{
    char Arr[20];
    
    printf("Enter the string :");
    scanf("%[^'\n]s",Arr);

    strRevX(Arr);

    printf("Reverse string is : %s",Arr);

    return 0;
}