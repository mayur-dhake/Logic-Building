//Write a program which accept string from user and accept one character. Check whether that character
//is present in string or not.

#include<stdio.h>
#include<stdbool.h>

bool CheckCharacter(char *str, char ch)
{
    while (*str != '\0')
    {
        if(*str == ch)
        {
            break;
        }
        str++;
    }

    if(*str == '\0')
    {
        return false;
    }
    else
    {
        return true;
    }
    
}

int main()
{
    char Arr[20];
    char cValue = 0;
    bool bRet = false;

    printf("Enter the string :");
    scanf("%[^'\n']s",Arr);

    printf("Enter the character :");
    scanf(" %c",&cValue);

    bRet = CheckCharacter(Arr, cValue);

    if(bRet == true)
    {
        printf("Character is present in the string.");   
    }
    else
    {
        printf("Character is not present in the string.");
    }


    return 0;
}