//Write a program which accepts number from user and display its table.

#include<stdio.h>

void Table(int iNo)
{
    int iCnt = 0;
    int Ans = 0;

    if(iNo < 0)
    {                                              //Updator
        iNo = -iNo;
    }

    for(iCnt = 1; iCnt <= 10; iCnt++)
    {
        Ans = iNo * iCnt;
        printf("%d\t",Ans);
    }
}

int main()
{
    int iValue = 0;

    printf("Enter the number :");
    scanf("%d",&iValue);

    Table(iValue);

    return 0;
}