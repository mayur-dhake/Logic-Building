/*Write a progam which accept number from user and if the number is less than 50 then print small, 
if it is greater 50 and less than 100 then print medium, if it is greater than 100 then print large.
*/

#include<stdio.h>

void Number(int iNo)
{
    if(iNo < 50)                                           
    {                                                      //In program it is not mention that what we have  
        printf("Small");                                   //to do with 50 and 100 that's why I did not give 
    }                                                      //= operator.
    else if((iNo > 50) && (iNo < 100))
    {
        printf("Medium");
    }
    else if(iNo > 100)
    {
        printf("Large");
    }


}

int main()
{
    int iValue = 0;

    printf("Enter number :");
    scanf("%d",&iValue);

    Number(iValue);



    return 0;
}