//Write a program to find the factorial of a given number.

#include<stdio.h>

int Factorial(int iNo)
{
    int iCnt = 0;
    int Ans = 1;

    if(iNo < 0)
    {
        iNo = -iNo;                              //Updator
    }

    for(iCnt = iNo; iCnt >= 1; iCnt--)
    {
        printf("%d\t",iCnt);
        Ans = Ans * iCnt;
    }
    return Ans;
}

int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter number :");
    scanf("%d",&iValue);

    iRet = Factorial(iValue);

    printf("\nFactorial of a number is : %d",iRet);


    return 0;
}