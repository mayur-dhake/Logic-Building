//Write a program which accept nubmer from user and return differnece between summation of even digits and
//summation of odd digits.

#include<stdio.h>

int CountDiff(int iNo)
{
    int iDigit = 0;
    int iEvenSum = 0;
    int iOddSum = 0;
    int iResult = 0;
    while(iNo != 0)
    {
        iDigit= iNo % 10;
        
        if((iDigit % 2) == 0)
        {
            iEvenSum = iEvenSum + iDigit;
        }
        if((iDigit % 2) == 1)
        {
            iOddSum = iOddSum + iDigit;
        }

        iNo = iNo / 10;
    }
    iResult = iEvenSum - iOddSum;

    return iResult;
}

int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter the number :");
    scanf("%d",&iValue);

    iRet = CountDiff(iValue);

    printf("Difference between summation of Even Digits and Summation of Odd Digits are : %d",iRet);

    return 0;
}