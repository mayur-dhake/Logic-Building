//Write a program which accept one number from user and range of position from user. Toggle all Bits from
//that range.

#include<iostream>
using namespace std;

typedef unsigned int UINT;

UINT ToggleBitRange(UINT iNo, int iStart, int iEnd)
{
    int iCnt = 0;
    for(iCnt = iStart; iCnt <= iEnd; iCnt++)            
    {
                                                        
    }
}

int main()
{
    UINT iValue = 0;
    int iFirst = 0;
    int iLast = 0;
    UINT iRet = 0;

    cout<<"Enter the number :"<<"\n";
    cin>>iValue;

    cout<<"Enter the position :"<<"\n";
    cin>>iFirst >>iLast;

    iRet = ToggleBitRange(iValue, iFirst, iLast);


    return 0;
}