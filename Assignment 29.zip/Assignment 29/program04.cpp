//Write a program which accept one number, two positions from user and chick whether bit at first and bit at
//second is ON or OFF.

#include<iostream>
using namespace std;

typedef unsigned int UINT;

void  CheckBit(UINT iNo, UINT iPos1, UINT iPos2)
{
    UINT iMask1 = 0X000000001;
    UINT iMask2 = 0X000000001;
    UINT iMask = 0X00000000;

    UINT iResult1 = 0X00000000;
    UINT iResult2 = 0X00000000;
    UINT iResult = 0X00000000;

    iMask1 = iMask1 << (iPos1 - 1);
    iMask2 = iMask2 << (iPos2 - 1);

    iResult1 = iNo & iMask1;
    iResult2 = iNo & iMask2;

    iMask = iMask1 | iMask2;
    iResult = iNo & iMask;

    if(iResult == iMask)
    {
        cout<<"Both the Bits are On"<<"\n";
    }
     else if(iResult1 == iMask1)
    {
        cout<<iPos1<<" th Bit is ON and "<<iPos2<<" th Bit is OFF."<<"\n";
    }
    else if(iResult2 == iMask2)
    {
        cout<<iPos2<<"th Bit is On and "<<iPos1<<" th Bit is OFF"<<"\n";
    }
    else
    {
        cout<<"Both the Bits are OFF"<<"\n";
    }
   
}

int main()
{
    UINT iValue = 0;
    UINT iBit1 = 0, iBit2 = 0;

    cout<<"Enter the number :"<<"\n";
    cin>>iValue;

    cout<<"Enter the first position :";
    cin>>iBit1;

    cout<<"Enter the second position :";
    cin>>iBit2;

    CheckBit(iValue, iBit1, iBit2);

    return 0;
}