//Write a program which accept two number from user and display position of common ON bits from that two numbers.

#include<iostream>
using namespace std;

typedef unsigned int UINT;

void CommonBits(UINT iNo1, UINT iNo2)
{
    UINT iMask = 0X00000001;
    int iCnt = 0;

    UINT iResult1 = 0;
    UINT iResult2 = 0;

    for(iCnt = 1; iCnt <= 32; iCnt++)
    {
        if((iNo1 & iMask) == iMask)
        {
            if((iNo2 & iMask) == iMask)
            {
                if((iNo1 & iMask) == (iNo2 & iMask))     
                {
                    cout<<iCnt<<"\n";
                }
            }
        }
        iMask = iMask << 1;
    }
}

int main()
{
    UINT iValue1 = 0;
    UINT iValue2 = 0;
    
    cout<<"Enter first number :";
    cin>>iValue1;

    cout<<"Enter second number :";
    cin>>iValue2;

    CommonBits(iValue1, iValue2);

    return 0;
}