//Write a program which accept one number from user and count number of ON (1) bits in it without using 
//% and / operator.

#include<iostream>
using namespace std;

typedef unsigned int UINT;

UINT CheckBit(UINT iNo)
{
    UINT iMask = 0X00000001;
    int iCnt = 0;
    int iCount = 0;

    for(iCnt = 1; iCnt <= 32; iCnt++)
    {
        if((iNo & iMask) == iMask)
        {
            iCount++;
        }
        iMask = iMask << 1;
    }
    return iCount;
}

int main()
{
    UINT iValue = 0;
    UINT iRet = 0;

    cout<<"Enter the number :"<<"\n";
    cin>>iValue;

    iRet = CheckBit(iValue);

    cout<<"Number of ON bits in a given number is :"<<iRet;
    return 0;
}