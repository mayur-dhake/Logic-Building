//Write a program to accept numbers from users and display the multiplication of factors.

#include<stdio.h>

int MultFact(int iNo)
{
    int iCnt = 0;
    int Mult = 1;

    for(iCnt = 1; iCnt <= (iNo / 2); iCnt++)     //Time complexity is O(n/2) where n is input given by the user.
    {
        if((iNo % iCnt) == 0)
        {
            printf("%d\t",iCnt);
            Mult = Mult * iCnt;
        }
    }
    return Mult;
}

int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter the no :");
    scanf("%d",&iValue);

    iRet = MultFact(iValue);

    printf("\nMultiplication is : %d",iRet);

    return 0;
}