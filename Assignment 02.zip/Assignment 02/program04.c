//Write a program to accept two numbers from users and display first number second number of times.

#include<stdio.h>

void Display(int iNo, int ifrequency)
{
    int iCnt = 0;

    for(iCnt =1; iCnt <= ifrequency; iCnt++)
    {
        printf("%d\t",iNo);
    }
}


int main()
{
    int iValue1 = 0;
    int iValue2 = 0;

    printf("Enter the no :");
    scanf("%d",&iValue1);

    printf("Enter the frequency :");
    scanf("%d",&iValue2);

    Display(iValue1, iValue2);


    return 0;
}