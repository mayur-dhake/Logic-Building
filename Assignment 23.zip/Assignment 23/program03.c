//Write a program to accept string from user and toggle the case.

#include<stdio.h>

void strtoggleX(char *str)
{
    int Gap = 'a' - 'A';

    while(*str != '\0')
    {
        if((*str >= 'a') && (*str <= 'z'))
        {
            *str = *str - Gap;
        }
        else if((*str >= 'A') && (*str <= 'Z'))
        {
            *str = *str + Gap;
        }

        str++;
    }
}

int main()
{
    char Arr[20];

    printf("Enter the string :");
    scanf("%[^'\n']s",Arr);

    strtoggleX(Arr);

    printf("String after editing is : %s",Arr);


    return 0;
}