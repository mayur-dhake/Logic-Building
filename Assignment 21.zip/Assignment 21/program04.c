//Write a program to accept character from user and check whether it is special symbol or not.

#include<stdio.h>
#include<stdbool.h>

bool CheckSpecial(char ch)
{   
    if((ch == '!') || (ch == '@') || (ch == '#') || (ch == '$') || (ch == '%') || (ch == '^') || (ch == '&') || (ch == '*'))
    {
        return true;
    }
    else
    {
        return false;
    }
    
}

int main()
{
    char cValue = '\0';
    bool bRet = false;

    printf("Enter the character :");
    scanf("%c",&cValue);

    bRet = CheckSpecial(cValue);

    if(bRet == true)
    {
        printf("The given character %c is special character.",cValue);
    }
    else
    {
        printf("The given character %c is not a special character.",cValue);
    }



    return 0;
}