//Write a program to accept character from user and display its ASCII value in decimal, octal and 
//Hexa-decimal format.

#include<stdio.h>

void DisplayASCII(char ch)
{   
    printf("Decimal Value of %c is %d.\n",ch,ch);
    printf("Octal Value of %c is %o.\n",ch,ch);
    printf("Hexa-decimal Value of %c is %x.",ch,ch);
}

int main()
{
    char cValue = '\0';

    printf("Enter the character :");
    scanf("%c",&cValue);

    DisplayASCII(cValue);

    return 0;
}