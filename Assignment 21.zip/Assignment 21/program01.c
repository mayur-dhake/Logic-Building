//Write a program which display ASCII table. Table contain symbols, Decimal, Hexa-decimal, and Octal representaion
//of every member from 0 to 255.

#include<stdio.h>

void DisplayASCII()
{
    int iCnt = 0;

    printf("Decimal\tHexa-Decimal\tOctal\tSymbol\n");
    
    for(iCnt = 0; iCnt <= 255; iCnt++)
    {
        printf("%u\t\t%x\t%o\t%c\n",iCnt,iCnt,iCnt,iCnt);
    }
}

int main()
{

    DisplayASCII();

    return 0;
}