// Write a program to print 5 to 1 number on the screen.

#include<stdio.h>

void Display()                                 //Assignment madhe khalil pramane dil ahe te jamal nahi 
{                                              //int i = 0;
    int i = 0;                                 //___ i = 5;
    int iCnt = 5;                              //
                                               //for(__; __; __)
    for(iCnt; iCnt >= 1; iCnt--)               //
    {                                          //
        printf("%d\t",iCnt);                   //printf("%d",i);
                                               //i++;
    }
}

int main()
{
    Display();


    return 0;
}