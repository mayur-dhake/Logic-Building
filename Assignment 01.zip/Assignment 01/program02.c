//Write a program to print "Marvellous" 5 times on the screen.

#include<stdio.h>

void Display(int iNo)
{
    int iCnt = 0;

    for(iCnt = 1; iCnt <= iNo; iCnt++)
    {
        printf("Marvellous\n");
    }
}

int main()
{
    int iValue = 0;

    printf("Enter how many time you want to print the statement :");
    scanf("%d",&iValue);

    Display(iValue);

    return 0;
}