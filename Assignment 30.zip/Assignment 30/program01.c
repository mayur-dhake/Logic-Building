//Write a program which search first occurence of particular element from signly linear linked list.

#include<stdio.h>
#include<stdlib.h>

struct Node
{
    int data;
    struct Node *next;
};

typedef struct Node NODE;
typedef struct Node * PNODE;
typedef struct Node ** PPNODE;

void InsertFirst(struct Node ** Head, int No)
{
    struct Node * newn = NULL;

    newn = (struct Node *)malloc(sizeof(struct Node));

    newn->data = No;
    newn->next = NULL;

    if(*Head == NULL)
    {
        *Head = newn;
    }
    else
    {
        newn->next = *Head;
        *Head = newn;
    }
}

void InsertLast(struct Node ** Head, int No)
{
    struct Node *newn = NULL;
    struct Node *temp = *Head;

    newn = (struct Node *)malloc(sizeof(struct Node));

    newn->data = No;
    newn->next = NULL;

    if(*Head == NULL)
    {
        *Head = newn;
    }
    else
    {
        while(temp -> next != NULL)
        {
            temp = temp -> next;
        }

        temp -> next = newn;
    }
}

void Display(struct Node * Head)
{
    printf("Elements of Linked List are :");

    while(Head != NULL)
    {
    printf("|%d| ->",Head->data);
    Head = Head -> next;
    }

    printf(" NULL\n");
}

int SearchFirstOccurance(struct Node *Head, int iNo)
{
    int iCnt = 1;

    while(Head != NULL)
    {
        if(Head -> data == iNo )
        {
            break;
        }

        iCnt++;
        Head = Head -> next;
    }

    if(Head == NULL)
    {
        return -1;
    }
    else
    {
        return iCnt;
    }
}

int main()
{
    int iRet = 0;
    int iValue = 0;
    struct Node * First = NULL;

    InsertFirst(&First,70);  
    InsertFirst(&First,30);  
    InsertFirst(&First,60);  
    InsertFirst(&First,50);  
    InsertFirst(&First,40);  
    InsertFirst(&First,30);  
    InsertFirst(&First,20);  
    InsertFirst(&First,10);  

    Display(First);

    printf("Enter the element you want to search :\n");
    scanf("%d",&iValue);

    iRet = SearchFirstOccurance(First, iValue);

    if(iRet == -1)
    {
        printf("There is no such element in the Linked List.\n");
    }
    else
    {
        printf("%d occured at Node %d",iValue,iRet);
    }

    return 0;
}