//Write a program which search last occurance of particular element from singly linear linked list.

#include<stdio.h>
#include<stdlib.h>

#define ERR_NOTFOUND -1

struct Node
{
    int data;
    struct Node *next;
};

void InsertLast(struct Node **Head, int No)
{
    struct Node *newn = NULL;
    struct Node * temp = *Head;

    newn = (struct Node *)malloc(sizeof(struct Node));

    newn->data = No;
    newn->next = NULL;

    if(*Head == NULL)
    {
        *Head = newn;
    }
    else
    {
        while(temp->next != NULL)
        {
            temp = temp -> next;
        }

        temp -> next = newn;
    }
}

void Display(struct Node *Head)
{
   printf("Elements of the Linked List are:"); 

   while(Head != NULL)
   {
    printf("|%d| -> ",Head->data);
    Head = Head -> next;
   } 

   printf("NULL\n");
}

int SearchLastOccurance(struct Node *Head, int iNo)
{
    int iPos = ERR_NOTFOUND;
    int iCnt = 1;

    while(Head != NULL)
    {
        if(Head->data == iNo)
        {
            iPos = iCnt;
        }
        iCnt++;
        Head = Head -> next;
    }

    return iPos;
}


int main()
{
    struct Node * First = NULL;
    int iValue = 0, iRet = 0;

    InsertLast(&First,10);
    InsertLast(&First,20);
    InsertLast(&First,30);
    InsertLast(&First,40);
    InsertLast(&First,50);
    InsertLast(&First,30);
    InsertLast(&First,70);

    Display(First);

    printf("Enter the element you want to search :\n");
    scanf("%d",&iValue);

    iRet = SearchLastOccurance(First, iValue);

    if(iRet == ERR_NOTFOUND)
    {
        printf("There is No such element in the linked list.\n");
    }
    else
    {
        printf("%d occured at index %d\n",iValue,iRet);
    }


    return 0;
}