// Write a program which return smallest element from singly linear linked list.

#include<stdio.h>
#include<stdlib.h>

struct Node
{
    int data;
    struct Node * next;
};

typedef struct Node NODE;
typedef struct Node * PNODE;
typedef struct Node ** PPNODE;

void InsertLast(PPNODE Head, int iNo)
{
    PNODE temp = *Head;
    PNODE newn = NULL;

    newn = (PNODE)malloc(sizeof(NODE));

    newn->data = iNo;
    newn->next = NULL;

    if(*Head == NULL)
    {
        *Head = newn;
    }
    else
    {
        while(temp->next != NULL)
        {
            temp = temp->next;
        }

        temp -> next = newn;
    }
}

void Display(PNODE Head)
{
    while(Head != NULL)
    {
        printf("|%d| ->",Head->data);
        Head = Head -> next;
    }
    printf("NULL\n");
}

int Smallest(PNODE Head)
{
    int iMin = Head->data;

    while(Head != NULL)
    {
        if(Head->data < iMin)
        {
            iMin = Head->data;
        }

        Head = Head -> next;
    }
    return iMin;
}

int main()
{
    PNODE First = NULL;
    int iRet = 0;

    InsertLast(&First,110);
    InsertLast(&First,230);
    InsertLast(&First,20);
    InsertLast(&First,240);
    InsertLast(&First,640);

    Display(First);

    iRet = Smallest(First);

    printf("Smallest no is :%d",iRet);

    return 0;
}