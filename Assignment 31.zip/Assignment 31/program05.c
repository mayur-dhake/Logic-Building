//Write a program which display addition of digits of elements from singly linear linked list.

#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
}NODE, *PNODE, **PPNODE;

void InsertFirst(PPNODE Head, int iNo)
{
    PNODE newn = NULL;

    newn = (PNODE)malloc(sizeof(NODE));

    newn->data = iNo;
    newn->next = NULL;

    if((*Head == NULL))
    {
        *Head = newn;
    }
    else
    {
        newn->next = *Head;
        *Head = newn;
    }
}

void Display(PNODE Head)
{
    while(Head != NULL)
    {
        printf("|%d| ->",Head->data);
        Head = Head ->next;
    }
    printf("NULL\n");
}

int Count(PNODE Head)
{
	int iCount = 0;
	while(Head != NULL)
	{
		iCount++;
		Head = Head ->next;
	}
	return iCount;
}


void SumDigit(PNODE Head)
{
    int iDigit = 0;
    int iSum = 0;
    int iCnt = 0;

    if(Head == NULL)
    {
        printf("Linked List is empty.");
        return;
    }

    while(Head != NULL)
    {
        iCnt++;

        while((Head->data) != 0 )
        {
            iDigit = (Head->data) % 10;
            iSum = iSum + iDigit;
             Head->data = (Head->data) / 10; 
        } 

        printf("Addition of all digits from the Node %d is : %d\n",iCnt,iSum);
        Head = Head -> next;       
        iSum = 0;
    }
}


int main()
{
    PNODE First = NULL;

    int iRet = 0;

    /*InsertFirst(&First, 640);
    InsertFirst(&First, 240);
    InsertFirst(&First, 20);
    InsertFirst(&First, 230);
    InsertFirst(&First, 110);*/
    if(First != NULL)
    {
        Display(First);
    }

    iRet = Count(First);

    SumDigit(First);

    return 0;
}