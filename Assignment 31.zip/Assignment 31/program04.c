//Write a program which return second maximum element from singly linear linked list.

#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
}NODE, *PNODE, **PPNODE;

void InsertFirst(PPNODE Head, int iNo)
{
    PNODE newn = NULL;

    newn = (PNODE)malloc(sizeof(NODE));

    newn->data = iNo;
    newn->next = NULL;

    if((*Head == NULL))
    {
        *Head = newn;
    }
    else
    {
        newn->next = *Head;
        *Head = newn;
    }
}

void Display(PNODE Head)
{
    while(Head != NULL)
    {
        printf("|%d| ->",Head->data);
        Head = Head ->next;
    }
    printf("NULL\n");
}

int Count(PNODE Head)
{
	int iCount = 0;
	while(Head != NULL)
	{
		iCount++;
		Head = Head ->next;
	}
	return iCount;
}


int SecondMaximum(PPNODE Head)
{
	int Max = 0;
	int second_Max = 0;
	PNODE temp = *Head;

	if(*Head == NULL)
	{
		printf("Linked List is empty.");
		return 0;
	}

	if(*Head == NULL)
	{
		printf("There is only one element in the linked list.");
		return 0;
	}


	if((temp->data) < (temp->next->data))
	{
		Max = temp->next->data;
		second_Max = temp->data;
	}
	else
	{
		Max = temp->data;
		second_Max = temp->next->data;
	}

	if((*Head)->next->next == NULL)
	{
		printf("Second Maximum element from linked list is :",second_Max);
	}
	else
	{
		while(temp != NULL)
		{
			if(temp->data > Max)
			{
				second_Max = Max;
				Max = temp->data;
			}
			else if(temp->data > second_Max)
			{
				second_Max = temp->data;
			}

			temp = temp -> next;
		}
	}

	return second_Max; 
}



int main()
{
    PNODE First = NULL;
    PNODE Last = NULL;
    int iRet = 0;

    InsertFirst(&First, 240);
    InsertFirst(&First, 320);
    InsertFirst(&First, 230);
    InsertFirst(&First, 110);

    Display(First);

	iRet = Count(First);
	printf("Number of nodes in the linked list are :%d\n",iRet);

    iRet = SecondMaximum(&First);

    printf("Second Maximum element from singly linear linked list is : %d",iRet);

    return 0;
}
