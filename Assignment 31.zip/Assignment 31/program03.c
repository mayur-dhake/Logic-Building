//Write a program which return addition of all even element from singly linear linked list.

#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
}NODE, *PNODE, **PPNODE;

void InsertFirst(PPNODE Head, PPNODE Tail, int iNo)
{
    PNODE newn = NULL;

    newn = (PNODE)malloc(sizeof(NODE));

    newn->data = iNo;
    newn->next = NULL;

    if((*Head == NULL) && (*Tail == NULL))
    {
        *Head = newn;
        *Tail = newn;
    }
    else
    {
        newn->next = *Head;
        *Head = newn;
    }
}

void Display(PNODE Head, PNODE Tail)
{
    while(Head != NULL)
    {
        printf("|%d| ->",Head->data);
        Head = Head ->next;
    }
    printf("NULL\n");
}

int AdditionEven(PNODE Head)
{
    int iSum = 0;

    while(Head != NULL)
    {
        if((Head->data % 2) == 0)
        {
            iSum = iSum + Head->data;
        }
        Head = Head -> next;
    }

    return iSum;
}

int main()
{
    PNODE First = NULL;
    PNODE Last = NULL;
    int iRet = 0;

    InsertFirst(&First, &Last, 41);
    InsertFirst(&First, &Last, 32);
    InsertFirst(&First, &Last, 20);
    InsertFirst(&First, &Last, 11);

    Display(First, Last);

    iRet = AdditionEven(First);

    printf("Addition of Even numbers from linked list are : %d",iRet);

    return 0;
}