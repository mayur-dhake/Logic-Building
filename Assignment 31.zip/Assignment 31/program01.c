//Write a program which displays all elements which are perfect from singly linear linked list.

#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

typedef struct node
{
    int data;
    struct node *next;
}NODE, *PNODE, **PPNODE;

void InsertFirst(PPNODE Head, int iNo)
{
    PNODE newn = NULL;

    newn = (PNODE)malloc(sizeof(NODE));

    newn->data = iNo;
    newn->next = NULL;

    if(*Head == NULL)
    {
        *Head = newn;
    }
    else
    {
        newn->next = *Head;
        *Head = newn;
    }
}

void Display(PNODE Head)
{
    while (Head != NULL)
    {
        printf("|%d| ->",Head->data);
        Head = Head -> next;
    }
    printf("NULL\n");
}

void DisplayPerfect(PNODE Head)
{
    int iCnt = 0;
    int iSum = 0;

    while(Head != NULL)
   {
        for(iCnt = 1; iCnt <= (Head->data/2); iCnt++)
        {
            if(((Head->data) % iCnt) == 0 )
            {
                iSum = iSum + iCnt;
            }
        }

        if(iSum == Head->data)
        {
            printf("%d is a perfect number\n",Head->data);
        }
        else
        {
            printf("%d is not a perfect number\n",Head->data);
        }

        Head = Head->next;
        iSum = 0;

   }
}

int main()
{
    PNODE First = NULL;
    
    InsertFirst(&First,89);
    InsertFirst(&First,6);
    InsertFirst(&First,41);
    InsertFirst(&First,17);
    InsertFirst(&First,28);
    InsertFirst(&First,11);

    Display(First);

    DisplayPerfect(First);


    return 0;
}