//Write a program which displays all elements which are prime from singly linear linked list.

#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

typedef struct node
{
    int data;
    struct node *next;
}NODE, *PNODE, **PPNODE;

void InsertLast(PPNODE Head, int iNo)
{
    PNODE newn = NULL;
    PNODE temp = *Head;

    newn = (PNODE)malloc(sizeof(NODE));

    newn->data = iNo;
    newn->next = NULL;

    if(*Head == NULL)
    {
        *Head = newn;
    }
    else
    {
        while(temp->next != NULL)
        {
            temp = temp -> next;
        }

        temp->next = newn;
    }
}

void Display(PNODE Head)
{
    while(Head != NULL)
    {
    printf("|%d| ->",Head->data);
    Head = Head->next;
    }
    printf("NULL\n");
}

void DisplayPrime(PNODE Head)
{
    int iCnt = 0;
    bool bFlag = true;

    while(Head != NULL)
    {
        for(iCnt = 2; iCnt <= (Head->data/2); iCnt++)
        {
            if((Head->data % iCnt) == 0)
            {
                bFlag = false;
                break;
            } 
            
        }

        if(bFlag == true)
        {
            printf("%d is a Prime Number.\n",Head->data);
        }
        else
        {
            printf("%d is not a Prime Number.\n",Head->data);
        }

        iCnt = 0;
        bFlag = true;
        Head = Head->next;

    } 
}

int main()
{

    PNODE First = NULL;

    InsertLast(&First,11);
    InsertLast(&First,20);
    InsertLast(&First,17);
    InsertLast(&First,41);
    InsertLast(&First,22);
    InsertLast(&First,89);

    Display(First);

    DisplayPrime(First);

    return 0;
}