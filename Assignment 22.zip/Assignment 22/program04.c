//Write a program which accept string from user and check whether it contains vowels in it or not.

#include<stdio.h>
#include<stdbool.h>

bool CheckVowel(char *str)
{   
    while (*str != '\0')
    {
        if((*str == 'a') || (*str == 'e') || (*str == 'i') || (*str == 'o') || (*str == 'u') || (*str == 'A') || (*str == 'E') || (*str == 'I') || (*str == 'O') || (*str == 'U'))   
        {
            break;
        }
        str++;
    }
    
    if(*str != '\0')
    {
        return true;
    }
    else
    {
        return false;
    }
 
}

int main()
{
    char Arr[20];
    bool bRet;

    printf("Enter the string :");
    scanf("%[^'\n']s",Arr);

    bRet = CheckVowel(Arr);

    if(bRet == true)
    {
        printf("The given string contains vowel in it.");
    }
    else
    {
        printf("The given string does not contain any vowel in it.");
    }

    return 0;
}