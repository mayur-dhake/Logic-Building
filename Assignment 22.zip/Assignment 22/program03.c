//Write a program which accept string from user and return differnece between frequency of small character
//and frequency of capital character.
#include<stdio.h>

int Difference(char *str)
{
    int iSmallCount = 0;
    int iCapitalCount = 0;
    int iReturn = 0;

    while (*str != '\0')
    {
        if((*str >= 'a') && (*str <= 'z'))
        {
            iSmallCount++;
        }
        else if((*str >= 'A') && (*str <= 'Z'))
        {
            iCapitalCount++;
        }
        str++;
    }

    iReturn = iCapitalCount - iSmallCount;
    if(iReturn < 0)
    {
        return -iReturn;
    }
    else
    {
        return iReturn;
    }
    
}

int main()
{
    char Arr[20];
    int iRet = 0;

    printf("Enter the string :");
    scanf("%[^'\n']s",Arr);

    iRet = Difference(Arr);

    printf("Difference between frequency of small character and frequency of capital character is %d",iRet);

    return 0;
}