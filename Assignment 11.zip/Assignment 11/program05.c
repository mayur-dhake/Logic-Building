//Write a program to accept N numbers from users and return product of all odd elements.

#include<stdio.h>
#include<stdlib.h>


int ProductOdd(int Arr[], int iLength)
{
    int iCnt = 0;
    int iSum = 1;
    int iCount = 0;

    for(iCnt = 0; iCnt < iLength; iCnt++)
    {
        if((Arr[iCnt] % 2) != 0)
        {
            iCount++;
            iSum = iSum * Arr[iCnt];
        }
    }

    if(iCount == 0)
    {
        return iCount;
    }
    else
    {
        return iSum;
    }
}
int main()
{
    int iSize = 0, iRet = 0, iCnt = 0;
    int *ptr = NULL;

    printf("Enter the number of elements :");
    scanf("%d",&iSize);

    ptr = (int *)malloc(iSize * sizeof(int));

    if(ptr == NULL)
    {
        printf("Unable to provide memory in the Heap");
        return -1;
    }

    printf("Enter the elements :");
    for(iCnt = 0; iCnt < iSize; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    iRet = ProductOdd(ptr, iSize);

    if(iRet == 0)
    {
        printf("There are no Odd numbers.");
    }
    else
    {
        printf("Product of the odd numbers are : %d",iRet);
    }

    free(ptr);

    return 0;
}