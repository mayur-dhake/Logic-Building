//Write a program which accept N nubmers from user and accept one another number as No, return index of 
//first occurence of that No.

#include<stdio.h>
#include<stdlib.h>

int FirstOccurence(int Arr[], int iLength, int iNo)
{
    int iCnt = 0;

    for(iCnt = 0; iCnt < iLength; iCnt++)
    {
        if(Arr[iCnt] == iNo)
        {
            break;
        }
    }

    if(iCnt == iLength)
    {
        return -1;
    }
    else
    {
        return iCnt;
    }
    
}
int main()
{
    int iSize = 0, iCnt = 0, iRet = 0, iValue = 0;
    int *ptr = NULL;

    printf("Enter the number of elements :");
    scanf("%d",&iSize);

    printf("Enter the number of which you want to return the index : ");
    scanf("%d",&iValue);

    ptr = (int *)malloc(iSize * sizeof(int));

    if(ptr == NULL)
    {
        printf("Unable to allocate memory in the Heap");
        return -1;
    }

    printf("Enter the elements :");
    for(iCnt = 0; iCnt < iSize; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    iRet = FirstOccurence(ptr, iSize, iValue);

    if(iRet == -1)
    {
        printf("There is no such number here");
    }
    else
    {
    printf("The number occured at index : %d",iRet);
    }

    free(ptr);

    return 0;
}