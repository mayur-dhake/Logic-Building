//Write a program which accept N number from user and accept range and display all element from that range.

#include<stdio.h>
#include<stdlib.h>

void Range(int Arr[], int iLength, int iNo1, int iNo2)
{
    int iCnt = 0;
    int iCount = 0;

    for(iCnt =0; iCnt < iLength; iCnt++)
    {
        if((Arr[iCnt] >= iNo1) && (Arr[iCnt] <= iNo2))
        {
            iCount++;
            printf("%d\t",Arr[iCnt]);
        }
       
    }

    if(iCount == 0)
    {
        printf("There are no elements in between the range of %d and %d",iNo1,iNo2);
    }
}

int main()
{
    int iSize = 0, iCnt = 0, iValue1 = 0, iValue2 = 0;
    int *ptr = NULL;

    printf("Enter the number of element :");
    scanf("%d",&iSize);

    printf("Enter the starting point :");
    scanf("%d",&iValue1);

    printf("Enter the ending point :");
    scanf("%d",&iValue2);

    ptr = (int *)malloc(iSize * sizeof(int));

    if(ptr == NULL)
    {
        printf("Unable to allocate memory in the Heap");
        return -1;
    }

    printf("Enter the elements :");
    for(iCnt = 0; iCnt < iSize; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    Range(ptr, iSize, iValue1, iValue2);

    free(ptr);

    return 0;
}