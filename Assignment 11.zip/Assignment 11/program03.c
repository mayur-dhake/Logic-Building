//Write a program to accept N number from user and accept one another number as No, return index 
//of last occurance of that No.

#include<stdio.h>
#include<stdlib.h>

#define ERR_NOTFOUND -1

int LastOccurance(int Arr[], int iLength, int iNo)
{
    int iCnt = 0;
    int iPos = ERR_NOTFOUND;

    for(iCnt = 0; iCnt < iLength; iCnt++)
    {
        if(Arr[iCnt] == iNo)
        {
            iPos = iCnt;
        }
    }
    return iPos;
}

int main()
{
    int iSize = 0, iRet = 0, iCnt = 0, iValue = 0;
    int *ptr = 0;

    printf("Enter the number of elemments :");
    scanf("%d",&iSize);

    printf("Enter the number of which you want to return the index of last occurance :");
    scanf("%d",&iValue);

    ptr  = (int *)malloc(iSize * sizeof(int));

    if(ptr == NULL)
    {
        printf("Unable to allocate memory in the Heap");
        return -1;
    }

    printf("Enter the elements :");
    for(iCnt = 0; iCnt < iSize; iCnt++)
    {
         scanf("%d",&ptr[iCnt]);
    }

    iRet = LastOccurance(ptr, iSize, iValue);

    if(iRet == ERR_NOTFOUND)
    {
        printf("There is no such element.");
    }
    else
    {
        printf("%d occured at index %d",iValue,iRet);
    }

    free(ptr);

    return 0;
}