#include<stdio.h>

int TouristBill(int iKilometer)
{
    if(iKilometer < 100)
    {
        return iKilometer * 25;
    }
    else if(iKilometer > 100)
    {
        return iKilometer * 15;
    }
}

int main()
{
    int iNo = 0;
    int iRet = 0;

    printf("Enter the no of kilometers car traveled :");
    scanf("%d",&iNo);

    iRet = TouristBill(iNo);

    printf("Estimated Rent of car travel is : %d",iRet);

    return 0;
}