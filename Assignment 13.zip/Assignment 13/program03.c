#include<stdio.h>

int SchoolFees(int iStdandard)
{
    int FirstStd_Fees = 8900;
    int SecondStd_Fees = 12790;
    int ThirdStd_Fees = 21000;
    int FourthStd_Fees = 23450;

    if(1 == iStdandard)
    {
        printf("Fees for standard one is :%d",FirstStd_Fees);
    }
    else if(2 == iStdandard)
    {
        printf("Fees for standard two is :%d",SecondStd_Fees);
    }
    else if(3 == iStdandard)
    {
        printf("Fees for standard three is :%d",ThirdStd_Fees);
    }
    else if(4 == iStdandard)
    {
        printf("Fees for standard four is %d",FourthStd_Fees);
    }
    else
    {
        printf("Plz Enter valid input.");
    }
}

int main()
{
    int iNo= 0;

    printf("Enter the standard :");
    scanf("%d",&iNo);

    SchoolFees(iNo);

    return 0;
}