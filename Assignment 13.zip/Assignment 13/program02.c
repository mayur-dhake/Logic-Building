#include<stdio.h>

#define FIRSTRANGE 500000
#define SECONDRANGE 1000000
#define THIRDRANGE 2000000

float IncomeTax(int iAmount)
{
    int iValue1 = iAmount - FIRSTRANGE;
    int iValue2 = iAmount - SECONDRANGE;
    int iValue3 = iAmount - THIRDRANGE;
    
    if(iAmount < FIRSTRANGE)
    {
        return 0;
    }
    else if((iAmount > FIRSTRANGE) && (iAmount < SECONDRANGE))
    {
        return iValue1 * 0.1;
    }
    else if((iAmount > SECONDRANGE) && (iAmount < THIRDRANGE))
    {
        return (FIRSTRANGE * 0.1) + (iValue2 * 0.2);
    }
    else if(iAmount > THIRDRANGE)
    {
        return (FIRSTRANGE * 0.1) + (SECONDRANGE * 0.2) + (iValue3 * 0.3);
    }
}

int main()
{
    int iNo;
    float iRet;

    printf("Enter the gross income :");
    scanf("%d",&iNo);

    iRet = IncomeTax(iNo);

    if(iRet == 0.0)
    {
        printf("There is no tax for you enjoy..");
    }
    else
    {
          printf("Income tax for your Gross income %d is %f",iNo,iRet);
    }

     return 0;
}