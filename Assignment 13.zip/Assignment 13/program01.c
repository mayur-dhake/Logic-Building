
#include<stdio.h>

int CalculateBill(int iAmount)
{
   /* int totalamount = 0;
    float discount = 0;

    if(iAmount < 500)
    {
        discount = 0;
    }
    else if((iAmount > 500) && (iAmount < 1500))
    {
        discount = 0.1;
    }
    else if(iAmount > 1500)
    {
        discount = 0.15;
    }

    totalamount = iAmount - (iAmount * discount);

    return totalamount;*/

    if(iAmount < 500)
    {
        return iAmount;
    }
    else if((iAmount > 500) && (iAmount < 1500))
    {
        return (iAmount - (iAmount * 10/100));
    }
    else if((iAmount > 1500))
    {
        return (iAmount - (iAmount * 15/100 ));
    }
}

int main()
{
    int iNo = 0;
    int iRet = 0;

    printf("Enter the bill :");
    scanf("%d",&iNo);

    iRet = CalculateBill(iNo);

    printf("Total bill after discount is : %d",iRet);

    return 0;
}