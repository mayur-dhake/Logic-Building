//Write a program to accept character from user and check whether it is alphabet or not.

#include<stdio.h>
#include<stdbool.h>

#define true 1
#define false 0

bool CheckAlphabet(char ch)
{
    if(((ch >= 'a') && (ch <= 'z')) || ((ch >= 'A') && (ch <= 'Z')))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int main()
{
    char cValue = '\0';
    bool bRet = false;

    printf("Enter the character :");
    scanf("%c",&cValue);

    bRet = CheckAlphabet(cValue);

    if(bRet == true)
    {
        printf("It is an alphabet");
    }
    else
    {
        printf("It is not an alphabet");
    }


    return 0;
}