//Write a program which accepts name from user and print that name.

#include<stdio.h>

int main()
{
    char Name[30];

    printf("Enter full name :");
    scanf("%s",&Name);                      //Full name possible nahi ahe karan space dila ki fakt suruvatich navach display hote.

    printf("Your name is : %s",Name);


    return 0;
}