//Write a program which accepts three numbers and print its multiplication.

#include<stdio.h>

int Multiply(int iNo1, int iNo2, int iNo3)
{
    int Ans = 0;

   if(iNo1 == 0)
   {
        if(iNo2 == 0)
        {
            if(iNo3 == 0)
            {
                Ans = 0;
            }
            else
            {
                Ans = iNo3;
            }
        }
        else
        {
            if(iNo3 == 0)
            {
                Ans = iNo2;
            }
            else
            {
                Ans = iNo2 * iNo3;
            }
        }
   }
   else if(iNo2 == 0)
   {
        if(iNo3 == 0)
        {
            Ans = iNo1;
        }
        else
        {
            Ans = iNo1 * iNo3;
        }
   }
   else if(iNo3 == 0)
   {
        Ans = iNo1 * iNo2;
   }   
   else
   {
        Ans = iNo1 * iNo2 * iNo3;
   }
   return Ans;
    
}

int main()
{
    int iValue1 = 0;
    int iValue2 = 0;
    int iValue3 = 0;
    int iRet = 0;

    printf("Please Enter three numbers :");
    scanf("%d%d%d",&iValue1,&iValue2,&iValue3);

    iRet = Multiply(iValue1, iValue2, iValue3);

    printf("Multiplication is : %d",iRet);



    return 0;
}