//Write a program which accepts total marks and obtained marks from user and calculate percentage.

#include<stdio.h>

int Percentage(int iNo1, float iNo2)
{
    float Ans = 0;

    if((iNo1 <= 0 ) || (iNo2 <= 0))
    {
        printf("Invalid Input\n");                          //Filter
        printf("Please Enter the marks greater than 0\n");
    }
    else
    {
         Ans = ( iNo2 / iNo1) * 100;                        //Assignment madhe iNo2 chya addhi int dil ahe but tas kel tar answer yet nahi
    }                                                       //possible asel tar answer provide kara.
    return Ans;
}



int main()
{
    int iValue1 = 0;
    float iValue2 = 0;
    float fRet = 0;

    printf("Please Enter total marks :");
    scanf("%d",&iValue1);

    printf("\nPlease Enter obtained marks :");
    scanf("%f",&iValue2);

    fRet = Percentage(iValue1, iValue2);

    printf("Percentage is :\t%f",fRet);




    return 0;
}