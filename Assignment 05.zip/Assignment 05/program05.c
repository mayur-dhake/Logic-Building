//Write a program which accept N and print first 5 multiple of N.

#include<stdio.h>

void MultipleDisplay(int iNo)
{
    int iCnt = 0;
    int Ans = 0;

    for(iCnt = 1; iCnt <= 5; iCnt++)
    {
        Ans = iNo * iCnt;

        printf("%d\t",Ans);
    }
        
}

int main()
{
    int iValue = 0;

    printf("Enter number :");
    scanf("%d",&iValue);

    MultipleDisplay(iValue);



    return 0;
}