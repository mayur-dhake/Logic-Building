//Write a program to accept number from user and display below pattern.

#include<stdio.h>

void Pattern(int iNo)
{
    int iCnt =0;
    int ch = '\0';

    for(iCnt = 'A'; iNo != 0 ; iCnt++)
    {
        printf("%c\t",iCnt);
        iNo--;
    }
}

int main()
{
    int iValue = 0;

    printf("Enter number of elements :");
    scanf("%d",&iValue);

    Pattern(iValue);

    return 0;
}